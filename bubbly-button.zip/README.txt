A Pen created at CodePen.io. You can find this one at https://codepen.io/nourabusoud/pen/ypZzMM.

 Inspired by:  https://dribbble.com/shots/3975065-With-a-Click-of-a-Button  By Gal Shir

Made the bubbles using  "radial-gradient" for background-image.
 I believe this property is so cool that you can draw many things without adding extra divs or pseudo elements  (::before and ::after)